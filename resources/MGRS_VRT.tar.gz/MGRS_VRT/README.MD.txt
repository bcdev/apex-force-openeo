### The collection of pre-compiled vrt for Copernicus DEM. 

This dataset features a collection of vrt files assigning for each MGRS tile corresponding Copernicus-DEM images. 
Due to the data embargo on the DEM tiles comprising the Caucasus region, the vrt dataset is incomplete. Specifically, the vrts for WGRS tiles T38SMH,	T38SMJ,	T38SNH,	T38SNJ,	T38SPH,	T38SPJ,	T38SQH,	T38SQJ,	T38TLK,	T38TLL,	T38TLM,	T38TMK,	T38TML,	T38TMM,	T38TNK,	T38TNL,	T38TNM,	T38TPK,	T38TPL,	T38TPM,	T38TQK,	T38TQL, T38TQM,	T39STC,	T39STD,	T39SUC,	T39SUD,	T39SVC,	T39SVD,	T39TTE,	T39TTF,	T39TTG,	T39TUE,	T39TUF,	T39TUG,	T39TVE,	T39TVF,	T39TVG,	T39TWE,	and T39TWF are either incomplete or not present. 
For the complete wall-to-wall DEM coverage, please extend this dataset by the patch `MGRS_VRT_Caucasus` incorporating SRTM DEM (30m) data. 

#### Setup
For the vrts to work as intended, all Copernicus DEM tiles should be already present in the respective data structures and the vrts should be places in one folder. Since the vrts use relative paths pointing to `../copernicus` the data structure should follow the organization depicted below.
WRS-2-specific tiles and MGRS-specific tiles can be stored in the same directory. 

```
# 
higher-level-dir
├── MGRS_VRT
│   ├── MGRS_T01CDH.vrt
│   ├── MGRS_T01CDJ.vrt
│   ...
│   └── MGRS_T60XWF.vrt
├── copernicus
│   ├── Copernicus_DSM_10_N00_00_E006_00_DEM.tif
│   ├── Copernicus_DSM_10_N00_00_E009_00_DEM.tif
│   ...
│   └── Copernicus_DSM_10_S90_00_W180_00_DEM.tif
...
```